/** Represents an Autovehicul, which is
 * a means of transportation.
 * @author Vlad Stoica
 */
public class Autovehicul {
    String tip;
    int gabarit;
    int cost;

    /** Creates an Autovehicul, without parameters.
     */
    Autovehicul() {
    }
}
